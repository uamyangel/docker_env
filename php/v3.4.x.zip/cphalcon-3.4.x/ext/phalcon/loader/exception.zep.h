
extern zend_class_entry *phalcon_loader_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Loader_Exception);

